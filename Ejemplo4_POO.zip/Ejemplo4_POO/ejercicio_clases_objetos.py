'''
    Crear una clase encapsulada Cliente con propiedades:
    nombre, CIF, vip:boolean, direccion (calle, numero, poblacion) (encapsulada)
    por defecto todos los clientes NO seran vip
    Crear el metodo __str__
    
    Crear 2 instancias y mostrarlas
'''

class Direccion:    
    def __init__(self, calle:str, numero:int, poblacion:str) -> None:
        self.setCalle(calle)
        self.setNumero(numero)
        self.setPoblacion(poblacion)
        
    def getCalle(self):
        return self.__calle
    
    def setCalle(self, calle):
        self.__calle = calle
    
    def getNumero(self):
        return self.__numero
    
    def setNumero(self, numero):
        if numero > 0:
            self.__numero = numero
        else:
            self.__numero = 0
            print("Numero no valido")
    
    def getPoblacion(self):
        return self.__poblacion
    
    def setPoblacion(self, poblacion):
        self.__poblacion = poblacion
        
    def __str__(self) -> str:
        # Gran Via, 5 (Madrid)
        return "{}, {} ({})".format(self.__calle, self.__numero, self.__poblacion)
    

class Cliente:
    def __init__(self, nombre:str, CIF:str,  direccion:Direccion, vip:bool = False) -> None:
        self.setNombre(nombre)
        self.setCIF(CIF)
        self.setVip(vip)
        self.setDireccion(direccion)
    
    def getNombre(self) -> str:
        return self.__nombre
    
    def setNombre(self, nombre) -> None:
        self.__nombre = nombre
    
    def getCIF(self):
        return self.__CIF
    
    def setCIF(self, CIF):
        self.__CIF = CIF
    
    def getVip(self):
        return self.__vip
    
    def setVip(self, vip):
        self.__vip = vip
    
    def getDireccion(self):
        return self.__direccion
    
    def setDireccion(self, direccion):
        self.__direccion = direccion
    
    def __str__(self) -> str:
        return ("Nombre: {} CIF: {} Vip: {} Direccion: {}"
                    .format(self.__nombre, self.__CIF, self.__vip, self.__direccion))
    

# Crear las instancias y mostrarlas
cli1 = Cliente("Transportes Perez", "12345678-A", Direccion("Mayor", 7, "Toledo"), True)
cli2 = Cliente("Fruteria Mary", "98765432-B", Direccion("Del Pozo", 45, "Sevilla"))

print(cli1)
print(cli2)