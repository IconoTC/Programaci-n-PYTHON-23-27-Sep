class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
    
    def __str__(self):
        return ("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))

class Empleado(Persona):
    def __init__(self, nombre, edad, sueldo) -> None:
        # Enviamos el nombre y la edad al constructor de la superclase
        super().__init__(nombre, edad)
        self.sueldo = sueldo
        
    # Sobreescribir el metodo heredado
    def __str__(self):
        # super().__str__() -> llamar al metodo str() de la superclase
        return  "{}, sueldo {}".format(super().__str__(), self.sueldo)   
    

empl1 = Empleado("Juan", 29, 43000)
empl1.edad += 1
print(empl1)