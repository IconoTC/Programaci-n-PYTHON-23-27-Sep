'''
    Crear la clase Decano: nombre, edad
    Crear la clase Universidad: nombre, direccion
    Crear la clase Ingenieria hereda de Profesor y Universidad
'''