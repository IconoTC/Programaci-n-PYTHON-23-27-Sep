'''
    Crear la clase Decano: nombre, edad
    Crear la clase Universidad: nombre, direccion
    Crear la clase Ingenieria hereda de Profesor y Universidad
'''
class Decano:
    def __init__(self, nombre, edad) -> None:
        self.__nombre = nombre
        self.__edad = edad
        
    def __str__(self) -> str:
        return "Nombre: {} Edad: {}".format(self.__nombre, self.__edad)
    
class Direccion:    
    def __init__(self, calle:str, numero:int, poblacion:str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def __str__(self) -> str:
        return "{}, {} ({})".format(self.calle, self.numero, self.poblacion)
    
class Universidad:   
    def __init__(self, nombre:str, direccion:Direccion) -> None:
        self.nombre = nombre
        self.direccion = direccion
    
    def __str__(self) -> str:
        return "Nombre {} Direccion: {}".format(self.nombre, self.direccion)
        
class Ingenieria(Decano, Universidad):
    def __init__(self, nombre_decano, edad, nombre, direccion, nombre_ingenieria, duracion) -> None:
        Decano.__init__(self,nombre_decano, edad)
        Universidad.__init__(self, nombre, direccion)
        self.nombre_ingenieria = nombre_ingenieria
        self.duracion = duracion
        
    def __str__(self) -> str:
        return "Decano: {} \nUniversidad {} \nIngenieria Nombre: {} Duracion: {}".format(
            Decano.__str__(self), Universidad.__str__(self), self.nombre_ingenieria, self.duracion)
        

informatica = Ingenieria("Jose Luis", 36, "Politecnica", Direccion("Moncloa", 5, "Madrid"), "Informatica", 4)
print(informatica)