'''
    Crear la clase FechaPublica (dia, mes, anyo)
    crear una instancia con datos correctos, p.e. fecha de hoy
    crear otra instancia erronea   67/92/-4
    mostrar ambas fechas __str__
    
    
    Crear la clase Fecha (dia, mes, anyo) con los atributos privados
    Crear los metodos publicos get y set
    en los metodos set crear validaciones:
        - el dia debe estar entre 1 y 30
        - el mes debe estar entre 1 y 12
        - el año debe ser 2024 o 2025
    crear una instancia con datos correctos, p.e. fecha de hoy
    crear otra instancia erronea   67/92/-4
    mostrar ambas fechas __str__
'''

class FechaPublica:
    def __init__(self, dia, mes, anyo) -> None:
        self.dia = dia
        self.mes = mes
        self.anyo = anyo
        
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.dia, self.mes, self.anyo)
    
hoy = FechaPublica(24,9,2024)
erronea = FechaPublica(67,92,-4)
print(hoy)
print(erronea)

class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
        
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son validos del 1 al 30
        if dia > 0 and dia < 31:
            self.__dia = dia
        else:
            self.__dia = 0
            print("Dia no valido")
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        # los meses son validos del 1 al 12
        if mes > 0 and mes <= 12:
            self.__mes = mes
        else:
            self.__mes = 0
            print("Mes no valido")
        
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # los años validos son 2024 y 2025
        if anyo == 2024 or anyo == 2025:
            self.__anyo = anyo
        else:
            self.__anyo = 0
            print("Año no valido")
            
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.__dia, self.__mes, self.__anyo)
    
hoy = Fecha(24,9,2024)
erronea = Fecha(67,92,-4)
print(hoy)
print(erronea)