class Direccion:    
    def __init__(self, calle:str, numero:int, poblacion:str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def __str__(self) -> str:
        # Equivalente al toString() de otros lenguajes
        # Retorna una cadena con la estado del objeto
        # Gran Via, 5 (Madrid)
        return "{}, {} ({})".format(self.calle, self.numero, self.poblacion)
    

class Persona:   
    def __init__(self, nombre:str, edad:int, direccion:Direccion) -> None:
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
    
    def mostrarInfo(self):
        print("Hola, me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion))
        
        
# crear objetos o instancias de Persona
dirJuan = Direccion("Gran Via", 5, "Madrid")
p1 = Persona("Juan", 35, dirJuan)
p2 = Persona("Maria", 42, Direccion("Diagonal", 134, "Barcelona"))

# Invocar a los recursos del objeto
p1.mostrarInfo()
p2.mostrarInfo()

# Diferencia __str__  y mostrarInfo()
print("Direccion de Juan", dirJuan)
print("Info de Maria", p2)

# los atributos o propiedades son publicas
p1.edad += 1
p1.direccion.calle = "Castellana"
p1.direccion.numero = 61
p1.mostrarInfo()