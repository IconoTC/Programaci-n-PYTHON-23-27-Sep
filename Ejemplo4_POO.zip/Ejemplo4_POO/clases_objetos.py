class Persona:
    
    # contructor o inicializador
    def __init__(self, nombre, edad) -> None:
        # pass   # significa que el cuerpo esta vacio {}
        self.nombre = nombre
        self.edad = edad
    
    def mostrarInfo(self):
        # print("Hola, me llamo", self.nombre, "y tengo", self.edad, "años")
        
        # NameError: name 'nombre' is not defined. Did you mean: 'self.nombre'?
        # print("Hola, me llamo {} y tengo {} años".format(nombre, edad))
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
        
# crear objetos o instancias de Persona
# p1 = Persona()  # TypeError: Persona.__init__() missing 2 required positional arguments: 'nombre' and 'edad'
p1 = Persona("Juan", 35)
p2 = Persona("Maria", 42)

# Invocar a los recursos del objeto
p1.mostrarInfo()
p2.mostrarInfo()

# los atributos o propiedades son publicas
p1.edad += 1
p1.mostrarInfo()