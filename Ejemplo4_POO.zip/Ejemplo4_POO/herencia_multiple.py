class Animal:
    def __init__(self, nombre, edad) -> None:
        self.__nombre = nombre
        self.__edad = edad
        
    def __str__(self) -> str:
        return "Nombre: {} Edad: {}".format(self.__nombre, self.__edad)
    
    
class ProductoVenta:
    def __init__(self, codigo, precio) -> None:
        self.__codigo = codigo
        self.__precio = precio
        
    def __str__(self) -> str:
        return "Codigo: {} Precio: {}".format(self.__codigo, self.__precio)
    
    
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo) -> None:
        Animal.__init__(self, nombre, edad)   # si llamamos al constructor por el nombre hay que enviar self
        ProductoVenta.__init__(self, codigo, precio)
        self.__vacunado = vacunado
        self.__sexo = sexo
        
    def __str__(self) -> str:
        return  "{} {} Vacunado: {} Sexo: {}".format(
            # Si llamamos al metodo por el nombre de la clase se necesita el self
            Animal.__str__(self), ProductoVenta.__str__(self), self.__vacunado, self.__sexo )
        
        
perro = Perro("Fifi", 3, "PE-001", 256.95, True, "Macho")
print(perro)