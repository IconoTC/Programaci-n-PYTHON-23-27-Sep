'''
    Crear una clase Figura con atributos: x,y
    metodo calcular_area
    metodo str -> [x,y]
    
    Crear la clase Circulo, Triangulo, Rectangulo
    sobreescribir metodo calcular_area
    optativo sobreescribir str para que aparezca: radio, base, altura, ...
    
    crear una instancia de cada figura y mostrar el area y el str
'''

class Figura:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
        
    def calcular_area(self):
        pass
    
    def __str__(self) -> str:
        return f"[{self.x},{self.y}]"
    
import math 
class Circulo(Figura):
    def __init__(self, x, y, radio) -> None:
        super().__init__(x, y)
        self.radio = radio
        
    def calcular_area(self):
        return math.pi * self.radio ** 2
    
    def __str__(self) -> str:
        return super().__str__() + f", Radio {self.radio}"
    
    
class Triangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura / 2
    
    def __str__(self) -> str:
        return super().__str__() + f", Base {self.base}, Altura {self.altura}"
    
    
class Rectangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura
    
    def __str__(self) -> str:
        return super().__str__() + f", Base {self.base}, Altura {self.altura}"
    
    
figura = Figura(23,12)
print("Area de la figura:", figura.calcular_area())   # None
print(figura)

circulo = Circulo(23,12,39.23)
print("Area del circulo:", circulo.calcular_area())   
print(circulo)

triangulo = Triangulo(23,12,40,30)
print("Area del triangulo:", triangulo.calcular_area())   
print(triangulo)

rectangulo = Rectangulo(23,12,40,30)
print("Area del rectangulo:", rectangulo.calcular_area())   
print(rectangulo)