# Crear una lista con las vocales
# Utilizando compresion, crear un diccionario donde:
#   - la clave es el indice de la lista
#   - el valor es la letra

lista = ['a','e','i','o','u']
resultado = { idx:lista[idx]  for idx in range(len(lista)) }
print(resultado)