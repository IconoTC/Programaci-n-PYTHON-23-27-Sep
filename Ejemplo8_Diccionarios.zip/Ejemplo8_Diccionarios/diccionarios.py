# diccionarios: los elementos son clave:valor
# No tienen indices, se accede a través de ls clave
# A partir de 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, se sobreescribe el valor
# Los valores si se pueden repetir
# Se crean con {}

# Si repito la clave, se sobreescribe el valor
alumnos = {'Juan': 6.4, "Maria": 8.3, "Luis": 6.4, "Adolfo": 7.1, "Maria": 9.3}
print(alumnos)
print(type(alumnos))  # <class 'dict'>

# Mostrar solo los nombres de los alumnos (claves)
print(alumnos.keys())  # dict_keys(['Juan', 'Maria', 'Luis', 'Adolfo'])

# Mostrar solo las notas de los alumnos (valores)
print(alumnos.values()) # dict_values([6.4, 9.3, 6.4, 7.1])

# Mostrar los elementos que tengo
# retorna una lista de tuplas
print(alumnos.items()) # dict_items([('Juan', 6.4), ('Maria', 9.3), ('Luis', 6.4), ('Adolfo', 7.1)])

# Operadores de pertenencia in y not in
print("Maria" in alumnos)

# Acceder a los elementos por su clave
print("Nota de Luis:", alumnos['Luis'])
# print("Nota de Luis:", alumnos['Luisa'])  # si no existe KeyError: 'Luisa'

print("Nota de Luis:", alumnos.get('Luis'))
print("Nota de Luis:", alumnos.get('Luisa'))  # si no existe devuelve None

# Borrar un elemento
del alumnos['Adolfo']    # si no existe KeyError: 'Otro'
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar el valor de un elemento
alumnos['Pepito'] = 5
print(alumnos)

# Eliminar el ultimo elemento
alumnos.popitem()
print(alumnos)

# Eliminar un elemento por su clave y retorna el valor
#print(alumnos.pop('Pepito'))  # si no existe KeyError: 'Pepito'
print(alumnos)

# Otra forma de agregar elementos al diccionario
alumnos.update({'Pepito': 5})
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:   # solo me devuelve las claves
    print(alum, alumnos[alum])

for item in alumnos.items():   # cada item es una tupla
    print(item)
    
for clave, valor in alumnos.items():   
    print(clave, ":", valor)
    
# Otras formas de crear diccionarios
alumnos = dict()
alumnos = {}
alumnos = dict([('Juan', 6.4), ("Maria", 8.3), ("Luis", 6.4), ("Adolfo", 7.1)]) 
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)