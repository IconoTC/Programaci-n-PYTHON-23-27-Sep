import pandas as pd

# https://pandas.pydata.org/docs/index.html

data = ['Juan', 'Pedro', 'Estefania', 'Ana', 'Esteban']
serie = pd.Series(data, dtype="string")
print(serie)

print("Longitud:", serie.size)
print("Indices:", serie.index)

# Acceso a los elementos
print(serie[0:2])   # muestra los 2 primeros, recordar que el ultimo no entra
print(serie[-2:])   # muestra los 2 ultimos
print(serie[3])     # muestra el que esta en el indice 3
print(serie[[1,4]]) # muestra el que esta en el indice 1 y 4

# Aplicar un lambda a una serie
serie = serie.apply(lambda nombre: nombre.upper())
print(serie)