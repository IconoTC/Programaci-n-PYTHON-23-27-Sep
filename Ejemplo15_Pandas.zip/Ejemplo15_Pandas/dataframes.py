import pandas as pd

# https://pandas.pydata.org/docs/index.html

# Crear el dataframe
data = [['Juan', 4.5], ['Pedro', 8.9], ['Estefania', 1.4], ['Ana', 5.6], ['Esteban', 7.8]]
columnasNombres = ['Nombre', 'Nota']
filas = list(range(5))
df = pd.DataFrame(data, columns=columnasNombres, index=filas)
print(df)

print(df.info)
print(df.shape)  # (5, 2)  filas,columnas
print(df.size)   # 10   5x2
print("Nombres columnas", df.columns) # Nombres columnas Index(['Nombre', 'Nota'], dtype='object')
print("Indices", df.index) # Indices Index([0, 1, 2, 3, 4], dtype='int64')
print(df.head(2))

# Mostrar los datos de una columna (Serie)
print("Nombres de los alumnos:", df['Nombre'])
print("Nombres de los alumnos:", df.Nombre)

# Mostrar los datos de una fila
print("Datos de Estefania", df.loc[2]) # loc -> accede al indice de la fila
print("Nota de Esteban", df.iloc[4,1]) # iloc -> accede a un valor por indices de fila,columna

# Filtrar por Esteban y mostrar su nota
notaEsteban = df[df['Nombre']=='Esteban']['Nota']   # df[filtro]['columna']
print(notaEsteban)

# Agregar nueva columna
resultado = ['Suspenso', 'Aprobado', 'Suspenso', 'Aprobado', 'Aprobado']
df.insert(loc=1, column="Resultado", value=resultado)   # loc=1 donde ponemos la columna, desplaza las demas
print(df)

print(df.groupby('Resultado').size())  # Muestra cuantos aprobados y cuantos suspensos
print(df.groupby('Resultado').count()) 

# Eliminar
df = df.drop(['Resultado'], axis=1)   # axis = 1 borro columnas
df = df.drop([4], axis=0)             # axis = 0 borro filas -> Eliminar a Esteban
print(df)