# Crear una funcion con argumento por defecto
def datosTrabajador(nombre, estadoCivil="Soltero", sueldo=24000):
    print(nombre, "esta", estadoCivil, "gana", sueldo)
    
datosTrabajador("Juan")  # el nombre es obligatorio
# datosTrabajador()   # TypeError: datosTrabajador() missing 1 required positional argument: 'nombre'
datosTrabajador("Maria", "Casada")
datosTrabajador("Pedro", "Separado", 35000)

# No interpreta que 40000 es el sueldo
datosTrabajador("Antonio", 40000)  # Antonio esta 40000 gana 24000
datosTrabajador("Antonio", sueldo=40000)  # Opcion correcta

print("a", "e", "i")  # sep=" "  end="\n"
print("a", "e", "i", sep="-")
print("a", "e", "i", sep="-", end=".")
print()


'''
    crear una funcion que reciba datos como numero variable de argumentos
    recibir un separador que por defecto sera " | "
    retornar el numero de datos recibidor y una cadena que una todos los datos con el separador (join)
'''

def concatenar(*datos, separador=" | "):
    return len(datos) ,separador.join(datos)

print(concatenar("a", "e", "i"))
print(concatenar("a", "e", "i", separador="-"))
print(concatenar("a", "e", "i", separador="/"))