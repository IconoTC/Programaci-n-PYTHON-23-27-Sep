# Funcion con un numero variable de argumentos
def sumar(*numeros):
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(7))
print(sumar(7, 2))
print(sumar(7, 2, 5))
print(sumar(7, 2, 5, 3))


# crear una funcion que recibe el nombre y las notas del alumno
# utilizando la funcion sumar() calcular la nota media
# devolver el nombre en mayusculas y la nota media
def procesarNotas(nombre, *notas):
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

print(procesarNotas("Juan", 2,5,3))
print(procesarNotas("Maria", 9,8))
print(procesarNotas("Pedro", 7,5,9,6))