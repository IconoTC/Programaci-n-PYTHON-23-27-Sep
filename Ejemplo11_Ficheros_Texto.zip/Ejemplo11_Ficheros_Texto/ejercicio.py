'''
    leer la informacion de fichero.txt y generar copia en copia.txt
'''

# Abrir el fichero en modo lectura
fichero_lectura = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero en modo lectura y escritura
fichero_copia = open("Ejemplo11_Ficheros_Texto/copia.txt", "w+t", encoding="utf-8")

# leer el contenido del fichero
contenido = fichero_lectura.readlines()

# escribir cada linea en otro fichero copia.txt
#fichero_copia.writelines(contenido)
for linea in contenido:
    fichero_copia.write(linea)

# leer el contenido creado
fichero_copia.seek(0)
for linea in fichero_copia.readlines():
    print(linea, end="")

# cerrar ambos ficheros
fichero_lectura.close()
fichero_copia.close()