# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 5
print("Division:", 7/5)  # 1.4
print("Division entera:", 7//5) # 1
print("Resto:", 7%5)  # 2
print("Potencia:", 7**5)  # 16807

# Operadores asignacion (+=,-=,*=,/=,%=,**=,//=)
numero1 += 5  # numero1 = numero1 + 5

# En Python no existen incrementos y decrementos
numero2 += 1     # numero2++
numero2 -= 1     # numero2--

# Operadores de comparación (<,>,<=,>=,==,!=)
print("Numero1 es menor:", numero1 < numero2)

nombre1 = "Juan"
nombre2 = "Juan"
print("Son iguales?",nombre1 == nombre2)

# Operadores logicos (and, or, not)
print("and:", (numero1 == 12 and nombre1 == 'Juan'))
print("or:", (numero1 == 12345 or nombre1 == 'Juan'))
print("not:", not(numero1 == 12345))

# Operadores de identidad (is, is not)
num1 = 6
num2 = 6
print("Es el mismo contenido", num1 is num2) # True

nombres1 = ["Juan", "Maria"]
nombres2 = ["Juan", "Maria"]
print("Es el mismo objeto", nombres1 is nombres2) # False porque las direcciones de memoria son distintas
print("Es distinto objeto", nombres1 is not nombres2)

# Operadores de pertenencia (in, not in)
print('Luis' in nombres1) # False
print('Luis' not in nombres1) # True
print('Maria' in nombres1) # True