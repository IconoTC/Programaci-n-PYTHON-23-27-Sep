import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato))  # str
numero1 = int(dato)
numero2 = int(input("Introduce otro numero: "))
print("Suma:", numero1 + numero2)

int("42")
#int("42.9")  # ValueError: invalid literal for int() with base 10: '42.9'
#int("42,9")  # ValueError: invalid literal for int() with base 10: '42,9'


# convertir de texto a numero real
radio = float(input("Introduce el radio del circulo: "))
print("Area del circulo:", math.pi * math.pow(radio, 2))
print("Area del circulo:", math.pi * radio ** 2)
# round(que, num_decimales)
print("Area del circulo:", round(math.pi * radio ** 2, 3))

radio2 = 67
print("Area del circulo:", math.pow(radio2, 2))
print("Area del circulo:", radio2 ** 2)


# convertir de texto a booleano
casado = "True"
print("Valor:", bool(casado), "Tipo:", type(bool(casado)))

# convertir a texto
texto1 = str(radio2)
print("Tipo:", type(texto1))