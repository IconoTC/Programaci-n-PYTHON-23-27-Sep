texto = "bienvenidos al curso de Python"
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())
print(texto.swapcase())

print("isalnum", texto.isalnum()) # False por los espacios en blanco
print("isalnum", "hola".isalnum())
print("isalnum", "12345".isalnum())

print("isalpha", texto.isalpha()) # False por los espacios en blanco
print("isalpha", "hola".isalpha())
print("isalpha", "12345".isalpha())

print("isdigit", texto.isdigit()) # False por textos y los espacios en blanco
print("isdigit", "hola".isdigit())
print("isdigit", "12345".isdigit())

print("isupper", texto.isupper())
print("isupper", "HOLA".isupper())
print("islower", texto.islower())
print("islower", "hola".islower())

ejemplo = "    Hoy es lunes    "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip() , end=".\n")
print("rstrip", ejemplo.rstrip() , end=".\n")
print("strip", ejemplo.strip() , end=".\n")

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())  # Es privado pero se permite acceder, FUNCIONA

print("Max:", max(texto))
print("Min:", min(texto), end=".\n")

print(texto.replace("e", "E")) # Cambia todas
print(texto.replace("i", "I", 1))  # Cambia una, la primera que encuentra

palabras = texto.split()  # Por defecto parte del espacio en blanco
print(palabras)
print("-".join(palabras))

fecha = "23/09/2024"
datos = fecha.split("/")
print("Dia:", datos[0])
print("Mes:", datos[1])
print("Año:", datos[2])

print(texto[0:11])