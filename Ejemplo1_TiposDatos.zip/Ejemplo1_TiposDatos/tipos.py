'''
    Comentarios de bloque
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 5
numero2 = 3
suma = numero1 + numero2
print(suma)
#print("Suma: " + suma)  # concatenar en Python solo se puede con strings
print("Suma:", suma)
print("Suma:", suma, ":", "Tipo:", type(suma))

# numeros reales (float)
base = 5.78
altura = 9.12
triangulo = base * altura / 2
print("Area del triangulo:", triangulo, ":", "Tipo:", type(triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, ":", type(soltero))

# cadenas de texto (str)
# se puede utilizar comillas dobles o simples
nombre = "Pepito"
apellido = 'Perez'
print(nombre, apellido, type(nombre))