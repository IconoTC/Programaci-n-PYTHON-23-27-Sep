'''
    Solicitar 2 numeros al usuario
    Mostrar suma, resta, multiplicacion, division, division entera, modulo y potencia
'''

numero1 = float(input("Introduce primer operando: "))   # 2.5
numero2 = float(input("Introduce segundo operando: "))  # 1.9

print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
#print("Resta:", round(numero1 - numero2, 2))

print("Multiplicacion:", numero1 * numero2)
print("Division:", numero1 / numero2)
print("Division entera:", numero1 // numero2)
print("Modulo:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)