import pickle

# Abrir el fichero en modo lectura y binario
fichero = open("Ejemplo12_Ficheros_Binarios/fichero.pckl", "rb")

# Recuperar el contenido
nombres = pickle.load(fichero)

# Mostrar el contenido y el tipo
print(nombres)
print(type(nombres))

# Cerrar el fichero
fichero.close()