import pickle

nombres = ["Juan", "Maria", "Pedro", "Luis"]

# Abrir el fichero en modo escritura y binario
fichero = open("Ejemplo12_Ficheros_Binarios/fichero.pckl", "wb")

# Escribir la lista nombres en el fichero
pickle.dump(nombres, fichero)

# Cerrar el fichero
fichero.close()