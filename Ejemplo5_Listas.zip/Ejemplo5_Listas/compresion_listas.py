# Ejemplo 1
# se trata de crear otra lista con la longitud de cada palabra
lista_palabras = ['casa', 'mesa', 'manzana', 'pijama']
longitud_palabras = []

for palabra in lista_palabras:
    longitud_palabras.append(len(palabra))
    
print("Longitud de palabras:", longitud_palabras)

''' compresion de lista'''
longitud_palabras = [len(palabra)  for palabra in lista_palabras]
print("Longitud de palabras:", longitud_palabras)


# Ejemplo 2
# se trata de crear la lista num_pares con los numeros pares del 0 al 10
num_pares = [num  for num in range(0,11)  if num % 2 == 0 ]
print(num_pares)


# Ejemplo 3
# Dado el siguiente vector crear un alista solo con numeros impares
# intentar que siga siendo de 2 dimensiones
vector = [ [1,2,3], [4,5,6], [7,8,9] ]
matriz_impares = [ [num for num in fila  if num % 2 != 0] for fila in vector ]
print(matriz_impares)