# listas de una dimension
lista = [1,2,3,4,5]  # un solo indice

# listas de 2 dimensiones
matriz = [ [2,7,4], [8,1,6], [3,9,5] ]   # 2 indices (fila, columna)

for fila in matriz:
    for num in fila:
        print(num, end=" ")
    print()
    
# matrices no cuadradas, cada fila tiene diferente numero de columnas
matriz2 = [ [2,7,4,1], [8,1], [3,9,5,6,0] ]

for fila in range(len(matriz2)):
    for col in range(len(matriz2[fila])):
        print(matriz2[fila][col], end=" ")
    print()