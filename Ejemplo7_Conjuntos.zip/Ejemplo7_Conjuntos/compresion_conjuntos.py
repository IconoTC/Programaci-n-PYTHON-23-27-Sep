# Ejercicio
# Con la palabra abracadabra crear un conjunto con las letras que no sean a,b,c
conjunto_letras = {letra  for letra in 'abracadabra' if letra not in {'a','b','c'} }
print(conjunto_letras)