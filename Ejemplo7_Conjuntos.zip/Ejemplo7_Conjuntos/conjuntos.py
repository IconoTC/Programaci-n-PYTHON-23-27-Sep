# conjuntos: colecciones sin orden, no usamos indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Se crean: {}
# CUIDADO!!!! conjunto = {}  lo interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(frutas)
print(type(frutas))   # <class 'set'>

# Conjunto vacio
conjunto = set()
conjunto = {}
print(type(conjunto))  # <class 'dict'> 

# agregar elementos al conjunto
frutas.add('fresas')
print(frutas)

# eliminar elemento
frutas.remove("platano")
print(frutas)

# longitud del conjunto
print("Longitud:", len(frutas))

# Recorrer conjuntos for in
for fruta in frutas:
    print(fruta, end=" ")
print()

# Copiar el conjunto en otro
otro = frutas.copy()

# Operadores in y not in
print("platano" in frutas)
print("fresas" in frutas)

# Borrar todos los elementos
frutas.clear()
print(frutas)