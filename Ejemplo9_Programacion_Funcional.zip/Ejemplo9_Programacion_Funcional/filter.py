# la funcion filter se aplica sobre una coleccion
# a traves de otra funcion filtramos los elementos
# la funcion tiene que devolver un valor booleano:
#       -True: pasa el filtro y nos lo quedamos
#       -False: no pasa el filtro y lo descartamos
# sintaxis: filter(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def soloPares(numero):
    if numero % 2 == 0:
        return True
    else:
        return False
    
numerosPares = list(filter(soloPares, numeros))
print(numerosPares)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=7.1)

def suspensos(item):
    if item[1] < 5:
        return True
    else:
        return False

alumnosSuspensos = dict(filter(suspensos, alumnos.items()))
print(alumnosSuspensos)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
    
    def __str__(self):
        return "Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad)
    
personas = [Persona("Juan", 27), Persona("Maria", 15), Persona("Pedro", 21)]

def menoresEdad(persona):
    if persona.edad < 18:
        return True
    else:
        return False

menores = list(filter(menoresEdad, personas))
for p in menores:
    print(p)