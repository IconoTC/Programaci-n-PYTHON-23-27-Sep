# la funcion map, se aplica sobre un coleccion donde
# con cada elemento se invoca a otra funcion que lo modifica
# o devuelve uno nuevo
# Importante que la funcion retorne un elemento
# sintaxis: map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(numero):
    return numero * 2

numerosDobles = list(map(duplicar, numeros))
print(numeros)  # la coleccion original no se modifica
print(numerosDobles)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def sumarPunto(item):
    return item[0], item[1] + 1

nuevasNotas = dict(map(sumarPunto, alumnos.items()))
print(nuevasNotas)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
    
    def __str__(self):
        return "Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad)
    
personas = [Persona("Juan", 27), Persona("Maria", 15), Persona("Pedro", 21)]

def modificarPersonas(persona: Persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona

personas = list(map(modificarPersonas, personas))
for p in personas:
    print(p)
print(personas)