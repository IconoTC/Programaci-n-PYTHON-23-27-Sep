# La funcion reduce le pasamos una coleccion
# retorna un solo resultado
# la funcion ha de tener 2 parametros:
#       - el primero actua como acumulador
#       - el segundo es el valor recibido
# sintaxis: reduce(funcion, coleccion)

''' Para utilizar reduce hay que importarlo '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

def sumar(acum, num):
    # la primera vez que se invoca se le pasan 2 agumentos: 3,8
    return acum + num

print("Suma:", reduce(sumar, numeros))


# Ejemplo 2
nombres = ["Juan", "Maria", "Pedro"]

def concatenar(resultado, nombre):
    return resultado.upper() + "-" + nombre.upper()

print(reduce(concatenar, nombres))