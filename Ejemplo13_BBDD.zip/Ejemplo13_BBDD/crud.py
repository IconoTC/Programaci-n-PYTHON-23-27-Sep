import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo13_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' Insertar datos 6 registros '''
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

lista = [ (3, 'Teclado', 29.50), (4, 'Raton', 18.90), (5, 'Impresora', 89.25), (6, 'Auriculares', 230) ]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)
#conexion.commit()

''' ********************  Consultas ****************** '''
# consultar y mostrar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()  # recoge todos los registros obtenidos
for prod in productos:
    print(prod)
print("------- FIN -------")


# consultar todos los productos con precio inferior a 50€
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------- FIN -------")


# todos los productos ordenados por descripcion: ascendente y descendente
cursor.execute("select * from PRODUCTOS order by descripcion asc")  # por defecto es ascendente
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------- FIN -------")

cursor.execute("select * from PRODUCTOS order by descripcion desc")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------- FIN -------")


# los productos cuya descripcion comiencen por la letra P
cursor.execute("select * from PRODUCTOS where descripcion LIKE 'P%'  ")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------- FIN -------")


""" ******************  Modificar **************  """
# Modificar el precio de la impresora
cursor.execute("update PRODUCTOS SET precio=140.0 where descripcion='Impresora' ")
conexion.commit()

query = "update PRODUCTOS SET precio=? where descripcion=? "
datos = (130, 'Impresora')  # tupla con los parametros
cursor.execute(query, datos)
conexion.commit()


# Modificar todas las descripciones en mayusculas
cursor.execute("update PRODUCTOS SET descripcion=upper(descripcion) ")
conexion.commit()


""" ****************** Eliminar ****************** """
# Eliminar el raton
query = "delete from PRODUCTOS where descripcion=?"
datos = ('RATON',)  # Hay que engañarle para que sea una tupla
cursor.execute(query, datos)
conexion.commit()

# Cerrar la conexion
conexion.close()