''' Generar la base de datos y la tabla '''

import sqlite3

# Crear la BBDD
# Abrir una conexion, si no existe la BBDD se crea
conexion = sqlite3.connect("Ejemplo13_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
cursor.execute("CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)")

# IMPORTANTE EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()