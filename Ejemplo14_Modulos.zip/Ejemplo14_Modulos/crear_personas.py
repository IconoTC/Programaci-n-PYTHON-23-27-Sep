'''  1ª forma  '''
import persona

luis = persona.Persona("Luis", 50)  # modulo.recurso
print(luis)


'''  2ª forma  '''
from persona import Persona
marta = Persona("Marta", 42)
print(marta)


'''  3ª forma  '''
from persona import Persona as Person
jorge = Person("Jorge", 25)
print(jorge)