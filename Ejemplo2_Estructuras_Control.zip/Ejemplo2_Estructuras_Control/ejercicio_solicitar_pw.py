'''
    Solicitar el pw al usuario hasta que acierte que es "curso"
    Solo tiene 3 intentos
    Cada vez que hay un fallo, mostrar cuantos intentos le quedan
    
    break;  da por terminado el bucle
    continue; da por terminada esa iteracion y pasa a la siguiente
'''

# Version 1
'''
pw = ''
intentos = 3
while pw != "curso" :
    pw = input("Introduce pw:")
    intentos -= 1
    if intentos == 0:
        print("Se agotaron los intentos")
        break
if pw == "curso":
    print("Has acertado")
'''

# Version 2
'''
intentos = 0
while intentos < 3:
    pw = input("Introduce pw:")
    if pw == "curso":
        print("Has acertado")
        break
    else:
        print("PW incorrecta, te quedan", 2-intentos, "intentos")
    intentos += 1
'''
    
# Version 3
for intento in range(3):
    pw = input("Introduce pw:")
    if pw == "curso":
        print("Has acertado")
        break
    else:
        print("PW incorrecta, te quedan", 2-intento, "intentos")