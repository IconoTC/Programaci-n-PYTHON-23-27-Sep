# Ejemplo 1
# crear una tupla con el cuadrado de cada numero
numeros = [1,2,3,4,5]
tupla_cuadrados = tuple((num**2) for num in numeros )
print(tupla_cuadrados)