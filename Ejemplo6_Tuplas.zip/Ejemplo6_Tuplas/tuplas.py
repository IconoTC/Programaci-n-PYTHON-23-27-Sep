# tuplas: colecciones ordenadas pero inmutables
# se permiten elementos duplicados
# se crean ()
# Ejemplos: dias de la semana, meses del año, estado civil, ...etc

# tuplas de 2 dimensiones estan permitidas
# slices funcionan igual que las listas
# operadores de pertenencia in y not in

dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(type(dias)) # <class 'tuple'>

# Crear la tupla vacia
tupla_vacia = ()
tupla_vacia = tuple()

# Mostrar la tupla
print(dias)

# Recorrer los elementos de la tupla

for dia in dias:
    print(dia)
    
for idx in range(len(dias)):
    print(dias[idx])
    
# Intentamos borrar el lunes
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# Concatenar tuplas
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# Para concatenar otra tupla ha de tener mas de un elemento
mas_dias = ('sabado', 'domingo')
otra_tupla = dias + mas_dias

# Longitud de la tupla
print("Longitud:", len(otra_tupla))

# Cuantos sabados hay
print("Sabados:", otra_tupla.count('sabado'))

# En que posicion esta el viernes
print("Posicion del viernes:", otra_tupla.index('viernes'))

# Convertir una tupla en lista
lista_dias = list(dias)
print(dias)
print(lista_dias)